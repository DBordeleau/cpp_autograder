#include <iostream>
#include <string>

int main() {
    std::cout << "Enter the first number: " << std::endl;
    int num1;
    std::cin >> num1;

    std::cout << "Enter the second number: " << std::endl;
    int num2;
    std::cin >> num2;

    int sum = num1 + num2;
    int product = num1 * num2;
    std::cout << "Sum: " << sum << std::endl;
    std::cout << "Product: " << product << std::endl;

    return 0;
}