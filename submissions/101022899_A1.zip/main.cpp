#include <iostream>
#include <string>

int main() {
    std::cout << "Enter your name: ";
    std::string name;
    std::cin >> name;
    std::cout << "Goodbye " << name << "!" << std::endl;
    return 0;
}